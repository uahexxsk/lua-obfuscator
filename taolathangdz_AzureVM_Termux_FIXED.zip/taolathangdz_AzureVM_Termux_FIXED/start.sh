#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$(dirname "$0")"
export LUA_BIN="${LUA_BIN:-lua5.1}"
export PORT="${PORT:-8788}"
if ! command -v node >/dev/null; then echo 'Node.js missing. Run ./install.sh'; exit 1; fi
if ! command -v "$LUA_BIN" >/dev/null; then echo "Lua executable '$LUA_BIN' missing. Run ./install.sh"; exit 1; fi
if [ ! -f azurevm-server.js ]; then echo 'azurevm-server.js missing'; exit 1; fi
if [ ! -f AzureVM-main/azure_obf.lua ]; then echo 'AzureVM source missing'; exit 1; fi
if [ ! -f taolathangdz.html ]; then echo 'HTML missing (taolathangdz.html)'; exit 1; fi
echo "AzureVM backend: http://127.0.0.1:$PORT"
echo "Open this in Chrome: http://127.0.0.1:$PORT/"
echo "Health: http://127.0.0.1:$PORT/health"
exec node azurevm-server.js
