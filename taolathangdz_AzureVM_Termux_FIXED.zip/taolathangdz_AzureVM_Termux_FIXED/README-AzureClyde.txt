Lonely OBF 5.24 — AzureVM + Clyde integration

Files:
- Lonely_5_24_OBF_xVMP_covirt_AzureClyde.html : modified web UI
- azurevm-server.js : local HTTP bridge that executes the real AzureVM Lua pipeline
- AzureVM-main/ : uploaded AzureVM repository, unchanged

Run:
1) Install Lua 5.1 or LuaJIT and ensure `lua` is on PATH.
2) Run: node azurevm-server.js
3) Open the HTML in a browser.
4) Select AzureVM and choose a preset.

The HTML does NOT silently replace AzureVM with reliableEncode/XOR if the backend fails. It reports the backend error instead.
Clyde Register/Stack remain browser-native pipelines already bundled in the HTML.
The SmallVMP size selector is now engine-specific; it does not cap other engines.
