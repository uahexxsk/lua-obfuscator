# AzureVM Android / Termux

## First run
Open Termux in this folder and run:

```bash
chmod +x install.sh start.sh stop.sh
./install.sh
```

## Start

```bash
./start.sh
```

Then open **http://127.0.0.1:8787/** in Chrome. The HTML is served by the same Node server, so you do not need to open the HTML as a `file://` page.

## Stop

```bash
./stop.sh
```

## Custom port

```bash
PORT=9000 ./start.sh
```

## Custom Lua executable

```bash
LUA_BIN=lua5.1 ./start.sh
```

AzureVM is executed through the included upstream `azure_obf.lua` pipeline. The server does not substitute the AzureVM engine with the generic XOR adapter when AzureVM fails; it returns the error instead.
