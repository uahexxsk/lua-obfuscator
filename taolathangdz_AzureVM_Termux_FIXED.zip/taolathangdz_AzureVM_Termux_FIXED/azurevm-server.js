const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { spawn } = require('child_process');

const PORT = Number(process.env.PORT || 8788);
const ROOT = path.resolve(process.env.AZUREVM_ROOT || path.join(__dirname, 'AzureVM-main'));
const LUA = process.env.LUA_BIN || (process.env.PREFIX ? 'lua5.1' : 'lua');
const HTML = path.resolve(process.env.AZUREVM_HTML || path.join(__dirname, 'taolathangdz.html'));

const PRESETS = new Set(['Luraph','Luraph14','Luraph15','AzureGod','AzureGod15','AzureGodUltra']);

function send(res, code, body, type='application/json') {
  res.writeHead(code, {'Content-Type': type, 'Access-Control-Allow-Origin':'*', 'Cache-Control':'no-store'});
  res.end(type === 'application/json' ? JSON.stringify(body) : body);
}
function runAzure(code, preset, seed) {
  return new Promise((resolve, reject) => {
    const id = crypto.randomBytes(10).toString('hex');
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'azurevm-'));
    const input = path.join(dir, `${id}.lua`);
    const output = path.join(dir, `${id}.out.lua`);
    fs.writeFileSync(input, code, 'utf8');
    const args = [path.join(ROOT,'azure_obf.lua'), input, '-o', output, '--preset', preset, '--seed', String(seed)];
    const child = spawn(LUA, args, {cwd: ROOT, stdio:['ignore','pipe','pipe']});
    let stdout='', stderr='';
    child.stdout.on('data', d => stdout += d.toString());
    child.stderr.on('data', d => stderr += d.toString());
    const timer = setTimeout(() => { child.kill('SIGKILL'); reject(new Error('AzureVM timed out after 60s')); }, 60000);
    child.on('error', err => { clearTimeout(timer); reject(err); });
    child.on('close', (status, signal) => {
      clearTimeout(timer);
      try {
        if (status !== 0) throw new Error(`AzureVM exited ${status}${signal ? ` (${signal})` : ''}: ${stderr || stdout}`);
        if (!fs.existsSync(output)) throw new Error('AzureVM produced no output');
        const result = fs.readFileSync(output, 'utf8');
        if (!result) throw new Error('AzureVM produced empty output');
        resolve(result);
      } catch (e) { reject(e); }
      finally { fs.rmSync(dir, {recursive:true, force:true}); }
    });
  });
}

const server = http.createServer((req,res) => {
  if (req.method === 'OPTIONS') { res.writeHead(204, {'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type'}); return res.end(); }
  if (req.method === 'GET' && req.url === '/health') return send(res,200,{ok:true, engine:'AzureVM', root:ROOT, lua:LUA});
  if (req.method === 'GET' && (req.url === '/' || req.url === '/index.html')) {
    if (!fs.existsSync(HTML)) return send(res,500,{error:'HTML file not found'});
    res.writeHead(200, {'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});
    return fs.createReadStream(HTML).pipe(res);
  }
  if (req.method !== 'POST' || req.url !== '/api/azurevm') return send(res,404,{error:'Not found'});
  let raw=''; req.on('data', c => { raw += c; if(raw.length > 25*1024*1024) req.destroy(); });
  req.on('end', async () => {
    try {
      const body=JSON.parse(raw || '{}');
      const code=String(body.code || '');
      const preset=PRESETS.has(body.preset) ? body.preset : 'AzureGodUltra';
      const seed=Number.isFinite(Number(body.seed)) ? Number(body.seed) : Date.now() % 2147483647;
      if(!code) return send(res,400,{error:'Missing code'});
      if(!fs.existsSync(path.join(ROOT,'azure_obf.lua'))) return send(res,500,{error:'AzureVM source not found'});
      const out=await runAzure(code,preset,seed);
      send(res,200,{code:out,preset,seed});
    } catch(e) { send(res,500,{error:String(e.message || e)}); }
  });
});
server.listen(PORT, '127.0.0.1', () => console.log(`AzureVM backend listening on http://127.0.0.1:${PORT}`));
