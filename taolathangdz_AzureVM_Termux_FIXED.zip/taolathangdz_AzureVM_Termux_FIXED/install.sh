#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$(dirname "$0")"
echo "== AzureVM Android installer =="
pkg update -y
pkg install -y nodejs lua51 unzip
chmod +x start.sh stop.sh
command -v node >/dev/null || { echo 'Node.js install failed'; exit 1; }
command -v lua5.1 >/dev/null || { echo 'Lua 5.1 install failed'; exit 1; }
node -v
lua5.1 -v
echo
echo "Installed. Run: ./start.sh"
