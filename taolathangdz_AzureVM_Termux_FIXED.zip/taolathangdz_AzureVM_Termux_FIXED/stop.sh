#!/data/data/com.termux/files/usr/bin/bash
pkill -f 'node azurevm-server.js' 2>/dev/null || true
echo 'AzureVM server stopped.'
